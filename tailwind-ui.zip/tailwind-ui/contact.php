<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tailwind Test</title>
    <link href="./dist/output.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/10.0.4/swiper-bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/10.0.4/swiper-bundle.min.css" />
</head>
<body class="bg-purple-200 dark:bg-purple-950 text-purple-950 dark:text-purple-200">

    <!-- Navbar -->
    <header class="p-5 shadow bg-white dark:bg-pink-800">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-2xl font-bold">WP Dev Blog</h1>
            <button id="theme-toggle" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 rounded">🌙</button>
        </div>
    </header>
        <!-- Link to Home Page -->
        <div class="mt-8">
            <p>Back to the <a href="index.html" class="text-indigo-600 hover:underline">Home Page</a></p>
        </div>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Email configuration
    $to = "programmer25@dynamicdreamz.com"; // Replace with your email
    $subject = "New Contact Form Submission";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: $email" . "\r\n";

    // Email body
    $body = "
    <html>
    <head>
        <title>$subject</title>
    </head>
    <body>
        <h2>Contact Form Submission</h2>
        <p><strong>Name:</strong> $name</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Message:</strong><br>$message</p>
    </body>
    </html>
    ";

    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo "<p class='text-center text-green-500'>Thank you for your message. We will get back to you soon!</p>";
    } else {
        echo "<p class='text-center text-red-500'>Sorry, something went wrong and we couldn't send your message.</p>";
    }
}
?>

</body>
</html>